# Challenge-3

# Concatenate Datasets

This script reads three separate CSV files containing data from Facebook, Google, and websites, respectively. It then merges these datasets based on domain and writes the concatenated dataset to a new CSV file.

## Input

The script expects three CSV files:
- `facebook_dataset.csv`: Contains data from Facebook with at least one column representing the root domain.
- `google_dataset.csv`: Contains data from Google with a column named `domain`.
- `website_dataset.csv`: Contains data from websites with at least one column representing the root domain.

## Output

The script generates a CSV file named `concatenated_dataset.csv` containing the merged data. Each row in the output file represents a domain, with columns from the Facebook, Google, and website datasets concatenated together.

## Notes

- The script assumes that the first row in each CSV file contains column headers.
- The script utilizes the `csv` module in Python for reading and writing CSV files.
