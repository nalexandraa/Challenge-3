import csv

# Define function to read CSV files
def read_csv_file(file_path, delimiter=','):
    data = []
    with open(file_path, "r", encoding="utf-8") as file:
        reader = csv.DictReader(file, delimiter=delimiter)
        for row in reader:
            data.append(row)
    return data

# Define function to merge datasets
def merge_datasets(facebook_data, google_data, website_data):
    merged_data = {}

    # Merge Facebook data
    for row in facebook_data:
        domain = row[root_domain_facebook]
        merged_data.setdefault(domain, {}).update({'facebook': row})

    # Merge Google data
    for row in google_data:
        domain = row['domain']
        merged_data.setdefault(domain, {}).update({'google': row})

    # Merge Website data
    for row in website_data:
        domain = row[root_domain_website]
        merged_data.setdefault(domain, {}).update({'website': row})

    return merged_data

# Read the Facebook dataset
facebook_data = read_csv_file("facebook_dataset.csv")

# Read the Google dataset
google_data = read_csv_file("google_dataset.csv")

# Read the Website dataset
website_data = read_csv_file("website_dataset.csv")

# Define root domain key for Facebook dataset
root_domain_facebook = list(facebook_data[0].keys())[0]

# Define root domain key for Website dataset
root_domain_website = list(website_data[0].keys())[0]

# Merge datasets
merged_data = merge_datasets(facebook_data, google_data, website_data)

# Concatenate data for each domain into one dataset
final_dataset = []
for domain, data in merged_data.items():
    entry = {'domain': domain}
    entry.update(data.get('facebook', {}))
    entry.update(data.get('google', {}))
    entry.update(data.get('website', {}))
    final_dataset.append(entry)

# Define the output CSV file path
output_file_path = "concatenated_dataset.csv"

# Write the concatenated dataset to a CSV file
if final_dataset:
    with open(output_file_path, "w", newline="", encoding="utf-8") as csvfile:
        fieldnames = final_dataset[0].keys()
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

        writer.writeheader()
        writer.writerows(final_dataset)

    print("Concatenated dataset has been written to:", output_file_path)
else:
    print("No data available to write to the CSV file.")
